from django.contrib import admin

# Register your models here.
from .models import Brand,Category,Product

class CategoryAdmin(admin.ModelAdmin):
    prepopulated_fields  = {'slug':('name',)}


class BrandAdmin(admin.ModelAdmin):
    prepopulated_fields  = {'slug':('name',)}


class ProductAdmin(admin.ModelAdmin):
    prepopulated_fields  = {'slug':('name',)}


admin.site.register(Brand,BrandAdmin)
admin.site.register(Category,CategoryAdmin)
admin.site.register(Product,ProductAdmin)

#
  #      <!--{{ product.get_absolute_url }} or  /products/{{product.slug}} it will also work {% url 'single_product' product.slug %}-->