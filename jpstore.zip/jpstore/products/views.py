from django.shortcuts import render,redirect
from django.http import HttpResponse,Http404

from .forms import ProductForm
from .models import Brand,Product,Category

# Create your views here.


def home(request):
    products = Product.objects.all()
    brands = Brand.objects.all()
    category = Category.objects.all()

    template = 'index.html'
    context={'products':products,'brands':brands,'category':category}

    return render(request,template,context)

def upload_product(request):
    form = ProductForm()
    if request.method == "POST":
        form = ProductForm(request.POST,request.FILES)

        if form.is_valid():
            form.save()
            return redirect('home')

        else:
            return HttpResponse('Invalid Data Entered.!')

    return render(request,'products/upload_form.html',{'upload_form':form})


def product(request,name):
   
    product = Product.objects.filter(name=name)
    context={'product':product}
    template = 'products/product_detail.html'
    print(product)
    return render(request,template,context)



def category(request,slug):
    try:
        cat = Category.objects.get(slug=slug)
    except Category.DoesNotExist:
        raise Http404

    products = Product.objects.filter(category=cat)
    print(products)
    context ={'products':products,'cat':cat}
    template = 'products/category.html'

    return render(request,template,context)


def brand(request,slug):
    try:
        cat = Brand.objects.get(slug=slug)
    except Brand.DoesNotExist:
        raise Http404

    products = Product.objects.filter(brand=cat)
    print(products)
    context ={'products':products,'brand':brand}
    template = 'products/brand.html'

    return render(request,template,context)



def userpanel(request):
    products = Product.objects.all()
    template='products/userpanel.html'
    context ={'products':products}

    return render(request,template,context)



def edit(request,id):
    product = Product.objects.get(id=id)
  
    update = ProductForm(request.POST or None,request.FILES or None,instance=product)
    if update.is_valid():
        update.save()
        return redirect('userpanel')

    return render(request,'products/upload_form.html',{'upload_form':update})

def delete(request,id):
    try:
        product = Product.objects.get(id=id)
    except Product.DeoesNotExist:
        raise Http404
    product.delete()
    return redirect('userpanel')

def search(request):
    try:
        q = request.GET.get('search')
    except:
        q = None
    if q:
        products = Product.objects.filter(name__icontains=q)
        template = 'products/search.html'
        context = {'query':q,'products':products}
    else:
        template = 'products/search.html'
        context = {}
    return render(request,template,context)
