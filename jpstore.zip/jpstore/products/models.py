from django.db import models
from django.urls import reverse

# Create your models here.

class Brand(models.Model):
    name = models.CharField(max_length=20)
    slug = models.SlugField(max_length=30)

    
    class Meta:
        verbose_name = ("Brand")
        verbose_name_plural = ("Brands")

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse("Brand_detail", kwargs={"slug": self.slug})


class Category(models.Model):
    name = models.CharField(max_length=20,null=False)
    slug = models.SlugField(max_length=30)

    class Meta:
        verbose_name = ("Category")
        verbose_name_plural = ("Categories")

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse("Category_detail", kwargs={"slug": self.slug})


class Product(models.Model):
    name = models.CharField(max_length=50,null=False)
    price = models.DecimalField(max_digits=10,decimal_places=2,null=False)
    image = models.ImageField()
    description = models.TextField(default='Write Book Summary')
    slug = models.SlugField(max_length=30)
    brand = models.ForeignKey(Brand,on_delete = models.SET_NULL,null=True)
    category = models.ManyToManyField(Category) 

    class Meta:
        verbose_name = ("Product")
        verbose_name_plural = ("Products")

    def __str__(self):
        return self.name

    def get_absolute_url(self):
       return reverse("product", kwargs={"name": self.name})
