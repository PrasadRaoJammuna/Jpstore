from django.conf.urls.static import static
from . import views 

from django.urls import path



urlpatterns = [
    path('',views.home,name='home'),
    path('upload/',views.upload_product,name='upload'),
    path('product/<str:name>',views.product,name='product'),
    path('category/<str:slug>',views.category,name='category'),
    path('brand/<str:slug>',views.brand,name='brand'),
    path('userpanel/',views.userpanel,name='userpanel'),
    path('edit/<int:id>/',views.edit,name='edit'),
    path('delete/<int:id>/',views.delete,name='delete'),
     path('s/',views.search,name='search'),
    
]
